# Everyone lives on one line: z = 0.5, the middle of the row of blocks at z = 0.

# Anyone who left and came back gets set up again.
execute as @a[scores={w2d_left=1..}] run function world_2d:join

# Players who just arrived: wait until the ground below them has loaded, then
# stand them on top of it. Give up after 10 seconds.
execute as @a[tag=w2d_fresh] at @s if loaded ~ ~ ~ positioned over motion_blocking_no_leaves run function world_2d:land
scoreboard players add @a[tag=w2d_fresh] w2d_age 1
tag @a[tag=w2d_fresh,scores={w2d_age=200..}] remove w2d_fresh

# Everybody else gets pulled back onto the line if they drift off it.
execute as @a[tag=!w2d_fresh] at @s unless predicate world_2d:on_line run tp @s ~ ~ 0.5
execute as @a at @s as @e[type=!minecraft:player,distance=..80] at @s unless predicate world_2d:on_line run tp @s ~ ~ 0.5

# Keep everybody looking north, so the camera behind you is always side-on.
execute as @a[tag=!w2d_fresh] unless entity @s[y_rotation=170..180] unless entity @s[y_rotation=-180..-170] run tp @s ~ ~ ~ 180 ~

# Clear the blocks between the camera and the line a few times a second.
scoreboard players add #clear w2d_timer 1
execute if score #clear w2d_timer matches 4.. as @a[tag=!w2d_fresh] at @s run fill ~-14 ~-9 1 ~14 ~9 9 minecraft:air
execute if score #clear w2d_timer matches 4.. run scoreboard players set #clear w2d_timer 0
